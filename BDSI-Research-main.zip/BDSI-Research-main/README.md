# BDSI-Data-mining
This is a repository of one of the subgroups of Data Mining at BDSI 2023. We explored feature selection in genomics and imaging data of Low Grade Glioma patients to predict survival time. Thanks to my wonderful teammates Mackenzie, Neo, Rosie without them it would have never been possible.
