load("pathway_scores.RData")
load("survival.RData")
load("pc_scores.rda")
